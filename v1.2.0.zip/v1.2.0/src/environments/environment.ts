


export const environment = {
  production: false,
  firebase: {
  
    apiKey: "AIzaSyAVBuAfRZf3uUHI14KbnWRBGOhdxdWhsOw",
    authDomain: "angular-login-4670a.firebaseapp.com",
    projectId: "angular-login-4670a",
    storageBucket: "angular-login-4670a.appspot.com",
    messagingSenderId: "554953473298",
    appId: "1:554953473298:web:12ce32f1823049016bc7cb",
    measurementId: "G-G809SL635H"
    
  },

};

